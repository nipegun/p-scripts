from django.core.wsgi import get_wsgi_application


# pylint: disable=invalid-name
application = get_wsgi_application()
