class DBDataError(ValueError):
    """
    A piece of information is missing from the database or in an unexpected state.
    """
